import React, { useContext, useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

import { tablecontext } from './App';

const Editform = () => {
    const {tabledata,settabledata,id,setid} = useContext(tablecontext);
   
    const [edit, setedit] = useState([]); 

    const edddit=tabledata.filter((i)=>i.id === id);

        console.log(edddit);
    
    // console.log(tabledata);
  return (  
    <div>
         {edddit.map((item) => {
                return (
          <Form style={{width:"400px",margin:"auto",border:"2px solid brown",padding:"30px",marginTop:"90px"}}  >
      <Form.Group className="mb-3">
        <Form.Label>Id</Form.Label>
        <Form.Control type='text' placeholder='enter Id' defaultValue="lala"/>
       
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Brand</Form.Label>
        <Form.Control type="text" placeholder="Brand"   />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Description</Form.Label>
        <Form.Control type="text" placeholder="Category"  />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicPassword">
      <Form.Label>Price</Form.Label>
        <Form.Control type="number" placeholder="Price" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="image-form">
      <Form.Label>Image Url</Form.Label>
        <Form.Control type="text" id='imageUrl' placeholder="Image Url"/>
      </Form.Group>
  
    
      <Button variant="primary" type="submit"style={{marginTop:"10px"}}>
        Add Product
      </Button>
     
    </Form>
      )  ; 
    }) } 
    </div>
  )
}

export default Editform